from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional
from datetime import datetime
from enum import Enum
import uuid

class SkillLevel(str, Enum):
    BEGINNER = "Beginner"
    INTERMEDIATE = "Intermediate"
    ADVANCED = "Advanced"

class CourseStatus(str, Enum):
    ACTIVE = "Active"
    INACTIVE = "Inactive"
    COMING_SOON = "Coming Soon"

# Course Models
class Course(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    description: str
    duration: str
    level: SkillLevel
    price: str
    features: List[str] = []
    image: str
    status: CourseStatus = CourseStatus.ACTIVE
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class CourseCreate(BaseModel):
    title: str
    description: str
    duration: str
    level: SkillLevel
    price: str
    features: List[str] = []
    image: str
    status: CourseStatus = CourseStatus.ACTIVE

class CourseUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    duration: Optional[str] = None
    level: Optional[SkillLevel] = None
    price: Optional[str] = None
    features: Optional[List[str]] = None
    image: Optional[str] = None
    status: Optional[CourseStatus] = None

# Student/User Models
class Student(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    email: EmailStr
    phone: Optional[str] = None
    enrolled_courses: List[str] = []  # Course IDs
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class StudentCreate(BaseModel):
    name: str
    email: EmailStr
    phone: Optional[str] = None

class StudentUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None

# Enrollment Models
class Enrollment(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    student_id: str
    course_id: str
    enrollment_date: datetime = Field(default_factory=datetime.utcnow)
    status: str = "Active"

class EnrollmentCreate(BaseModel):
    student_id: str
    course_id: str

# Testimonial Models
class Testimonial(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    role: str
    image: str
    testimonial: str
    rating: int = Field(ge=1, le=5)
    course: str
    is_featured: bool = False
    created_at: datetime = Field(default_factory=datetime.utcnow)

class TestimonialCreate(BaseModel):
    name: str
    role: str
    image: str
    testimonial: str
    rating: int = Field(ge=1, le=5)
    course: str
    is_featured: bool = False

# FAQ Models
class FAQ(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    question: str
    answer: str
    category: Optional[str] = None
    order: int = 0
    is_active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)

class FAQCreate(BaseModel):
    question: str
    answer: str
    category: Optional[str] = None
    order: int = 0
    is_active: bool = True

# Contact Models
class ContactSubmission(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    email: EmailStr
    phone: Optional[str] = None
    course_interest: Optional[str] = None
    message: str
    status: str = "New"  # New, Contacted, Resolved
    created_at: datetime = Field(default_factory=datetime.utcnow)

class ContactSubmissionCreate(BaseModel):
    name: str
    email: EmailStr
    phone: Optional[str] = None
    course_interest: Optional[str] = None
    message: str

# Demo Request Models
class DemoRequest(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: EmailStr
    name: Optional[str] = None
    phone: Optional[str] = None
    course_interest: Optional[str] = None
    status: str = "Pending"  # Pending, Scheduled, Completed, Cancelled
    created_at: datetime = Field(default_factory=datetime.utcnow)

class DemoRequestCreate(BaseModel):
    email: EmailStr
    name: Optional[str] = None
    phone: Optional[str] = None
    course_interest: Optional[str] = None

# Instructor Models
class Instructor(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    title: str
    company: str
    image: str
    expertise: List[str] = []
    bio: Optional[str] = None
    is_active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)

class InstructorCreate(BaseModel):
    name: str
    title: str
    company: str
    image: str
    expertise: List[str] = []
    bio: Optional[str] = None
    is_active: bool = True

# Stats Models
class Stats(BaseModel):
    students_trained: str = "10,000+"
    placement_rate: str = "95%"
    industry_partners: str = "500+"
    years_experience: str = "15+"
    updated_at: datetime = Field(default_factory=datetime.utcnow)

# Response Models
class APIResponse(BaseModel):
    success: bool
    message: str
    data: Optional[dict] = None

class PaginatedResponse(BaseModel):
    success: bool
    message: str
    data: List[dict]
    total: int
    page: int
    per_page: int
    total_pages: int