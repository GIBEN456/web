import os
from motor.motor_asyncio import AsyncIOMotorClient
import logging

logger = logging.getLogger(__name__)

# Database connection
mongo_url = os.environ.get('MONGO_URL')
if not mongo_url:
    raise ValueError("MONGO_URL environment variable is not set")

client = AsyncIOMotorClient(mongo_url)
db = client[os.environ.get('DB_NAME', 'offenso_academy')]

async def get_database():
    """Get database instance"""
    return db

async def init_database():
    """Initialize database with sample data"""
    try:
        # Check if data already exists
        course_count = await db.courses.count_documents({})
        if course_count > 0:
            logger.info("Database already initialized with sample data")
            return
        
        # Sample courses data
        sample_courses = [
            {
                "id": "course_1",
                "title": "Offenso Certified Security Analyst",
                "description": "Master the fundamentals of cybersecurity with hands-on labs and real-world scenarios.",
                "duration": "6 months",
                "level": "Beginner",
                "price": "$1,299",
                "features": ["24/7 Lab Access", "Industry Projects", "Placement Support", "CompTIA Aligned"],
                "image": "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
                "status": "Active"
            },
            {
                "id": "course_2",
                "title": "Offenso Certified Security Professional",
                "description": "Advanced cybersecurity training for professionals looking to specialize in enterprise security.",
                "duration": "8 months",
                "level": "Intermediate",
                "price": "$1,899",
                "features": ["Advanced Penetration Testing", "Incident Response", "Security Architecture", "CISSP Prep"],
                "image": "https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
                "status": "Active"
            },
            {
                "id": "course_3",
                "title": "Advanced Diploma in Information Security",
                "description": "Comprehensive program covering all aspects of information security and risk management.",
                "duration": "12 months",
                "level": "Advanced",
                "price": "$2,499",
                "features": ["Digital Forensics", "Malware Analysis", "Cloud Security", "Certification Guarantee"],
                "image": "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
                "status": "Active"
            },
            {
                "id": "course_4",
                "title": "Certified Junior Whitehat Hacker",
                "description": "Ethical hacking fundamentals with practical penetration testing skills.",
                "duration": "4 months",
                "level": "Beginner",
                "price": "$899",
                "features": ["Web Application Security", "Network Penetration", "Social Engineering", "Bug Bounty Training"],
                "image": "https://images.unsplash.com/photo-1614064641938-3bbee52942c7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
                "status": "Active"
            },
            {
                "id": "course_5",
                "title": "Offenso Certified SOC Expert",
                "description": "Specialized training for Security Operations Center analysts and managers.",
                "duration": "6 months",
                "level": "Intermediate",
                "price": "$1,599",
                "features": ["SIEM Technologies", "Threat Hunting", "Incident Response", "SOC Management"],
                "image": "https://images.unsplash.com/photo-1518709268805-4e9042af2176?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
                "status": "Active"
            }
        ]
        
        # Sample testimonials
        sample_testimonials = [
            {
                "id": "testimonial_1",
                "name": "Sarah Johnson",
                "role": "Senior Security Analyst at CyberTech Corp",
                "image": "https://images.unsplash.com/photo-1494790108755-2616b6096a99?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80",
                "testimonial": "Offenso Academy transformed my career. The hands-on training and placement support helped me land my dream job in cybersecurity.",
                "rating": 5,
                "course": "Offenso Certified Security Professional",
                "is_featured": True
            },
            {
                "id": "testimonial_2",
                "name": "Michael Chen",
                "role": "Ethical Hacker at SecureNet Solutions",
                "image": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80",
                "testimonial": "The practical approach and expert trainers made all the difference. I'm now earning 6 figures as an ethical hacker.",
                "rating": 5,
                "course": "Certified Junior Whitehat Hacker",
                "is_featured": True
            },
            {
                "id": "testimonial_3",
                "name": "Emily Rodriguez",
                "role": "SOC Manager at Global Finance Inc",
                "image": "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80",
                "testimonial": "Excellent program with real-world applications. The SOC Expert course prepared me perfectly for my management role.",
                "rating": 5,
                "course": "Offenso Certified SOC Expert",
                "is_featured": True
            }
        ]
        
        # Sample FAQs
        sample_faqs = [
            {
                "id": "faq_1",
                "question": "What are the prerequisites for enrolling in cybersecurity courses?",
                "answer": "Most of our beginner courses require basic computer literacy and networking knowledge. Advanced courses may require prior cybersecurity experience or relevant certifications.",
                "category": "General",
                "order": 1,
                "is_active": True
            },
            {
                "id": "faq_2",
                "question": "Do you offer online and offline classes?",
                "answer": "Yes, we offer flexible learning options including online, offline, and hybrid classes to accommodate different learning preferences and schedules.",
                "category": "General",
                "order": 2,
                "is_active": True
            },
            {
                "id": "faq_3",
                "question": "What kind of placement assistance do you provide?",
                "answer": "We offer comprehensive placement assistance including resume building, interview preparation, industry connections, and job placement support with our partner companies.",
                "category": "Career",
                "order": 3,
                "is_active": True
            },
            {
                "id": "faq_4",
                "question": "Are the courses industry-recognized?",
                "answer": "Yes, our courses are aligned with CompTIA standards and other industry certifications. We also provide preparation for globally recognized cybersecurity certifications.",
                "category": "Certification",
                "order": 4,
                "is_active": True
            },
            {
                "id": "faq_5",
                "question": "Can I get a free demo class?",
                "answer": "Absolutely! We offer free demo classes for all our courses. You can book a demo session to experience our teaching methodology and curriculum.",
                "category": "General",
                "order": 5,
                "is_active": True
            },
            {
                "id": "faq_6",
                "question": "What is the duration of the courses?",
                "answer": "Course durations vary from 4 months to 12 months depending on the complexity and depth of the program. Each course is designed to provide comprehensive knowledge in the respective domain.",
                "category": "General",
                "order": 6,
                "is_active": True
            }
        ]
        
        # Sample instructors
        sample_instructors = [
            {
                "id": "instructor_1",
                "name": "Dr. Alex Thompson",
                "title": "Chief Security Officer",
                "company": "Former CISO at Fortune 500",
                "image": "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80",
                "expertise": ["Penetration Testing", "Security Architecture", "Risk Management"],
                "is_active": True
            },
            {
                "id": "instructor_2",
                "name": "Maria Garcia",
                "title": "Senior Security Researcher",
                "company": "Cybersecurity Expert",
                "image": "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80",
                "expertise": ["Malware Analysis", "Digital Forensics", "Incident Response"],
                "is_active": True
            },
            {
                "id": "instructor_3",
                "name": "James Wilson",
                "title": "Ethical Hacker",
                "company": "Bug Bounty Hunter",
                "image": "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80",
                "expertise": ["Web Application Security", "Network Security", "Social Engineering"],
                "is_active": True
            }
        ]
        
        # Insert sample data
        await db.courses.insert_many(sample_courses)
        await db.testimonials.insert_many(sample_testimonials)
        await db.faqs.insert_many(sample_faqs)
        await db.instructors.insert_many(sample_instructors)
        
        # Insert default stats
        default_stats = {
            "students_trained": "10,000+",
            "placement_rate": "95%",
            "industry_partners": "500+",
            "years_experience": "15+"
        }
        await db.stats.insert_one(default_stats)
        
        logger.info("Database initialized with sample data successfully")
        
    except Exception as e:
        logger.error(f"Error initializing database: {str(e)}")
        raise