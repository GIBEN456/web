from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from ..models import Testimonial, TestimonialCreate, APIResponse
from ..database import get_database

router = APIRouter(prefix="/testimonials", tags=["testimonials"])

@router.get("/", response_model=List[Testimonial])
async def get_testimonials(
    featured_only: bool = Query(False),
    limit: int = Query(10, ge=1, le=50),
    skip: int = Query(0, ge=0)
):
    """Get all testimonials with optional filtering"""
    db = await get_database()
    
    try:
        filter_query = {}
        if featured_only:
            filter_query["is_featured"] = True
        
        testimonials = await db.testimonials.find(filter_query).skip(skip).limit(limit).to_list(limit)
        return [Testimonial(**testimonial) for testimonial in testimonials]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching testimonials: {str(e)}")

@router.get("/{testimonial_id}", response_model=Testimonial)
async def get_testimonial(testimonial_id: str):
    """Get a specific testimonial by ID"""
    db = await get_database()
    
    try:
        testimonial = await db.testimonials.find_one({"id": testimonial_id})
        if not testimonial:
            raise HTTPException(status_code=404, detail="Testimonial not found")
        return Testimonial(**testimonial)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching testimonial: {str(e)}")

@router.post("/", response_model=APIResponse)
async def create_testimonial(testimonial: TestimonialCreate):
    """Create a new testimonial"""
    db = await get_database()
    
    try:
        new_testimonial = Testimonial(**testimonial.dict())
        await db.testimonials.insert_one(new_testimonial.dict())
        
        return APIResponse(
            success=True,
            message="Testimonial created successfully",
            data=new_testimonial.dict()
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating testimonial: {str(e)}")

@router.get("/featured/list", response_model=List[Testimonial])
async def get_featured_testimonials(limit: int = Query(6, ge=1, le=20)):
    """Get featured testimonials for homepage"""
    db = await get_database()
    
    try:
        testimonials = await db.testimonials.find(
            {"is_featured": True}
        ).limit(limit).to_list(limit)
        
        return [Testimonial(**testimonial) for testimonial in testimonials]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching featured testimonials: {str(e)}")