from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from ..models import FAQ, FAQCreate, APIResponse
from ..database import get_database

router = APIRouter(prefix="/faq", tags=["faq"])

@router.get("/", response_model=List[FAQ])
async def get_faqs(
    category: Optional[str] = None,
    active_only: bool = Query(True),
    limit: int = Query(50, ge=1, le=100),
    skip: int = Query(0, ge=0)
):
    """Get all FAQs with optional filtering"""
    db = await get_database()
    
    try:
        filter_query = {}
        if category:
            filter_query["category"] = category
        if active_only:
            filter_query["is_active"] = True
        
        faqs = await db.faqs.find(filter_query).sort("order", 1).skip(skip).limit(limit).to_list(limit)
        return [FAQ(**faq) for faq in faqs]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching FAQs: {str(e)}")

@router.get("/{faq_id}", response_model=FAQ)
async def get_faq(faq_id: str):
    """Get a specific FAQ by ID"""
    db = await get_database()
    
    try:
        faq = await db.faqs.find_one({"id": faq_id})
        if not faq:
            raise HTTPException(status_code=404, detail="FAQ not found")
        return FAQ(**faq)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching FAQ: {str(e)}")

@router.post("/", response_model=APIResponse)
async def create_faq(faq: FAQCreate):
    """Create a new FAQ"""
    db = await get_database()
    
    try:
        new_faq = FAQ(**faq.dict())
        await db.faqs.insert_one(new_faq.dict())
        
        return APIResponse(
            success=True,
            message="FAQ created successfully",
            data=new_faq.dict()
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating FAQ: {str(e)}")

@router.get("/categories/list", response_model=List[str])
async def get_faq_categories():
    """Get all FAQ categories"""
    db = await get_database()
    
    try:
        categories = await db.faqs.distinct("category", {"is_active": True})
        return [cat for cat in categories if cat]  # Filter out None values
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching categories: {str(e)}")