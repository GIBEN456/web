from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from ..models import Course, CourseCreate, CourseUpdate, SkillLevel, APIResponse
from ..database import get_database
from datetime import datetime

router = APIRouter(prefix="/courses", tags=["courses"])

@router.get("/", response_model=List[Course])
async def get_courses(
    level: Optional[SkillLevel] = None,
    status: Optional[str] = None,
    limit: int = Query(10, ge=1, le=100),
    skip: int = Query(0, ge=0)
):
    """Get all courses with optional filtering"""
    db = await get_database()
    
    # Build filter query
    filter_query = {"status": {"$ne": "Inactive"}}
    
    if level:
        filter_query["level"] = level
    if status:
        filter_query["status"] = status
    
    try:
        courses = await db.courses.find(filter_query).skip(skip).limit(limit).to_list(limit)
        return [Course(**course) for course in courses]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching courses: {str(e)}")

@router.get("/{course_id}", response_model=Course)
async def get_course(course_id: str):
    """Get a specific course by ID"""
    db = await get_database()
    
    try:
        course = await db.courses.find_one({"id": course_id})
        if not course:
            raise HTTPException(status_code=404, detail="Course not found")
        return Course(**course)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching course: {str(e)}")

@router.post("/", response_model=APIResponse)
async def create_course(course: CourseCreate):
    """Create a new course"""
    db = await get_database()
    
    try:
        new_course = Course(**course.dict())
        await db.courses.insert_one(new_course.dict())
        
        return APIResponse(
            success=True,
            message="Course created successfully",
            data=new_course.dict()
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating course: {str(e)}")

@router.put("/{course_id}", response_model=APIResponse)
async def update_course(course_id: str, course_update: CourseUpdate):
    """Update an existing course"""
    db = await get_database()
    
    try:
        # Check if course exists
        existing_course = await db.courses.find_one({"id": course_id})
        if not existing_course:
            raise HTTPException(status_code=404, detail="Course not found")
        
        # Update fields
        update_data = {k: v for k, v in course_update.dict().items() if v is not None}
        update_data["updated_at"] = datetime.utcnow()
        
        await db.courses.update_one(
            {"id": course_id},
            {"$set": update_data}
        )
        
        return APIResponse(
            success=True,
            message="Course updated successfully"
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating course: {str(e)}")

@router.delete("/{course_id}", response_model=APIResponse)
async def delete_course(course_id: str):
    """Delete a course (soft delete by setting status to Inactive)"""
    db = await get_database()
    
    try:
        result = await db.courses.update_one(
            {"id": course_id},
            {"$set": {"status": "Inactive", "updated_at": datetime.utcnow()}}
        )
        
        if result.matched_count == 0:
            raise HTTPException(status_code=404, detail="Course not found")
        
        return APIResponse(
            success=True,
            message="Course deleted successfully"
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error deleting course: {str(e)}")

@router.get("/featured/list", response_model=List[Course])
async def get_featured_courses(limit: int = Query(6, ge=1, le=20)):
    """Get featured courses for homepage"""
    db = await get_database()
    
    try:
        courses = await db.courses.find(
            {"status": "Active"}
        ).limit(limit).to_list(limit)
        
        return [Course(**course) for course in courses]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching featured courses: {str(e)}")