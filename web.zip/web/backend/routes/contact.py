from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from ..models import ContactSubmission, ContactSubmissionCreate, DemoRequest, DemoRequestCreate, APIResponse
from ..database import get_database

router = APIRouter(prefix="/contact", tags=["contact"])

@router.post("/submit", response_model=APIResponse)
async def submit_contact_form(submission: ContactSubmissionCreate):
    """Submit a contact form"""
    db = await get_database()
    
    try:
        new_submission = ContactSubmission(**submission.dict())
        await db.contact_submissions.insert_one(new_submission.dict())
        
        return APIResponse(
            success=True,
            message="Contact form submitted successfully. We'll get back to you within 24 hours.",
            data={"submission_id": new_submission.id}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error submitting contact form: {str(e)}")

@router.post("/demo-request", response_model=APIResponse)
async def request_demo(demo_request: DemoRequestCreate):
    """Request a free demo"""
    db = await get_database()
    
    try:
        # Check if demo request already exists for this email
        existing_request = await db.demo_requests.find_one({
            "email": demo_request.email,
            "status": {"$in": ["Pending", "Scheduled"]}
        })
        
        if existing_request:
            return APIResponse(
                success=True,
                message="Demo request already exists. We'll contact you soon.",
                data={"request_id": existing_request["id"]}
            )
        
        new_request = DemoRequest(**demo_request.dict())
        await db.demo_requests.insert_one(new_request.dict())
        
        return APIResponse(
            success=True,
            message="Demo request submitted successfully. We'll contact you within 24 hours.",
            data={"request_id": new_request.id}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error submitting demo request: {str(e)}")

@router.get("/submissions", response_model=List[ContactSubmission])
async def get_contact_submissions(
    status: Optional[str] = None,
    limit: int = Query(50, ge=1, le=200),
    skip: int = Query(0, ge=0)
):
    """Get contact submissions (admin endpoint)"""
    db = await get_database()
    
    try:
        filter_query = {}
        if status:
            filter_query["status"] = status
        
        submissions = await db.contact_submissions.find(filter_query).skip(skip).limit(limit).to_list(limit)
        return [ContactSubmission(**submission) for submission in submissions]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching submissions: {str(e)}")

@router.get("/demo-requests", response_model=List[DemoRequest])
async def get_demo_requests(
    status: Optional[str] = None,
    limit: int = Query(50, ge=1, le=200),
    skip: int = Query(0, ge=0)
):
    """Get demo requests (admin endpoint)"""
    db = await get_database()
    
    try:
        filter_query = {}
        if status:
            filter_query["status"] = status
        
        requests = await db.demo_requests.find(filter_query).skip(skip).limit(limit).to_list(limit)
        return [DemoRequest(**request) for request in requests]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching demo requests: {str(e)}")