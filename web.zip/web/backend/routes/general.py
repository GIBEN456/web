from fastapi import APIRouter, HTTPException
from typing import List
from ..models import Stats, Instructor, APIResponse
from ..database import get_database

router = APIRouter(prefix="/general", tags=["general"])

@router.get("/stats", response_model=Stats)
async def get_stats():
    """Get academy statistics"""
    db = await get_database()
    
    try:
        stats = await db.stats.find_one({})
        if not stats:
            # Return default stats if none found
            default_stats = Stats()
            await db.stats.insert_one(default_stats.dict())
            return default_stats
        
        return Stats(**stats)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching stats: {str(e)}")

@router.get("/instructors", response_model=List[Instructor])
async def get_instructors(active_only: bool = True):
    """Get all instructors"""
    db = await get_database()
    
    try:
        filter_query = {}
        if active_only:
            filter_query["is_active"] = True
        
        instructors = await db.instructors.find(filter_query).to_list(100)
        return [Instructor(**instructor) for instructor in instructors]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching instructors: {str(e)}")

@router.get("/health", response_model=APIResponse)
async def health_check():
    """Health check endpoint"""
    return APIResponse(
        success=True,
        message="API is running successfully"
    )