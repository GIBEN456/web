from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from ..models import Student, StudentCreate, StudentUpdate, Enrollment, EnrollmentCreate, APIResponse
from ..database import get_database
from datetime import datetime

router = APIRouter(prefix="/students", tags=["students"])

@router.post("/", response_model=APIResponse)
async def create_student(student: StudentCreate):
    """Create a new student"""
    db = await get_database()
    
    try:
        # Check if student with email already exists
        existing_student = await db.students.find_one({"email": student.email})
        if existing_student:
            raise HTTPException(status_code=400, detail="Student with this email already exists")
        
        new_student = Student(**student.dict())
        await db.students.insert_one(new_student.dict())
        
        return APIResponse(
            success=True,
            message="Student created successfully",
            data=new_student.dict()
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating student: {str(e)}")

@router.get("/{student_id}", response_model=Student)
async def get_student(student_id: str):
    """Get a specific student by ID"""
    db = await get_database()
    
    try:
        student = await db.students.find_one({"id": student_id})
        if not student:
            raise HTTPException(status_code=404, detail="Student not found")
        return Student(**student)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching student: {str(e)}")

@router.get("/email/{email}", response_model=Student)
async def get_student_by_email(email: str):
    """Get a student by email"""
    db = await get_database()
    
    try:
        student = await db.students.find_one({"email": email})
        if not student:
            raise HTTPException(status_code=404, detail="Student not found")
        return Student(**student)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching student: {str(e)}")

@router.post("/enroll", response_model=APIResponse)
async def enroll_student(enrollment: EnrollmentCreate):
    """Enroll a student in a course"""
    db = await get_database()
    
    try:
        # Check if student exists
        student = await db.students.find_one({"id": enrollment.student_id})
        if not student:
            raise HTTPException(status_code=404, detail="Student not found")
        
        # Check if course exists
        course = await db.courses.find_one({"id": enrollment.course_id})
        if not course:
            raise HTTPException(status_code=404, detail="Course not found")
        
        # Check if already enrolled
        existing_enrollment = await db.enrollments.find_one({
            "student_id": enrollment.student_id,
            "course_id": enrollment.course_id,
            "status": "Active"
        })
        if existing_enrollment:
            raise HTTPException(status_code=400, detail="Student is already enrolled in this course")
        
        # Create enrollment
        new_enrollment = Enrollment(**enrollment.dict())
        await db.enrollments.insert_one(new_enrollment.dict())
        
        # Update student's enrolled courses
        await db.students.update_one(
            {"id": enrollment.student_id},
            {
                "$addToSet": {"enrolled_courses": enrollment.course_id},
                "$set": {"updated_at": datetime.utcnow()}
            }
        )
        
        return APIResponse(
            success=True,
            message="Student enrolled successfully",
            data=new_enrollment.dict()
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error enrolling student: {str(e)}")

@router.get("/{student_id}/enrollments", response_model=List[dict])
async def get_student_enrollments(student_id: str):
    """Get all enrollments for a student with course details"""
    db = await get_database()
    
    try:
        # Get student enrollments
        enrollments = await db.enrollments.find({"student_id": student_id}).to_list(100)
        
        # Get course details for each enrollment
        enrollment_details = []
        for enrollment in enrollments:
            course = await db.courses.find_one({"id": enrollment["course_id"]})
            if course:
                enrollment_details.append({
                    "enrollment_id": enrollment["id"],
                    "course": course,
                    "enrollment_date": enrollment["enrollment_date"],
                    "status": enrollment["status"]
                })
        
        return enrollment_details
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching enrollments: {str(e)}")

@router.post("/quick-enroll", response_model=APIResponse)
async def quick_enroll(name: str, email: str, course_id: str):
    """Quick enrollment - create student and enroll in course"""
    db = await get_database()
    
    try:
        # Check if student exists
        existing_student = await db.students.find_one({"email": email})
        
        if existing_student:
            student_id = existing_student["id"]
        else:
            # Create new student
            new_student = Student(name=name, email=email)
            await db.students.insert_one(new_student.dict())
            student_id = new_student.id
        
        # Check if course exists
        course = await db.courses.find_one({"id": course_id})
        if not course:
            raise HTTPException(status_code=404, detail="Course not found")
        
        # Check if already enrolled
        existing_enrollment = await db.enrollments.find_one({
            "student_id": student_id,
            "course_id": course_id,
            "status": "Active"
        })
        if existing_enrollment:
            return APIResponse(
                success=True,
                message="Student is already enrolled in this course"
            )
        
        # Create enrollment
        new_enrollment = Enrollment(student_id=student_id, course_id=course_id)
        await db.enrollments.insert_one(new_enrollment.dict())
        
        # Update student's enrolled courses
        await db.students.update_one(
            {"id": student_id},
            {
                "$addToSet": {"enrolled_courses": course_id},
                "$set": {"updated_at": datetime.utcnow()}
            }
        )
        
        return APIResponse(
            success=True,
            message="Student enrolled successfully"
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error in quick enrollment: {str(e)}")